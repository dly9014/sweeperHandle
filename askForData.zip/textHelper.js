
'use strict';
var textHelper = (function () {

    return {
        completeHelp: 'Here\'s some things you can say,'
        + ' A'
        + ' B'
        + ' C'
        + ' D'
        + ' E'
        + ' and exit.',

    };
})();
module.exports = textHelper;
