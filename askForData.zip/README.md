# askForData
Node front end microservice to ask Alexa to retrieve data
