# sweeperHandle
Lambda front-end microservice requester of json via Sweeper
